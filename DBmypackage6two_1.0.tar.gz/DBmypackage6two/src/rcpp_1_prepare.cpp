//Basic functions in preparation: linear regression, sample, and projection

// -*- mode: C++; c-indent-level: 4; c-basic-offset: 4; indent-tabs-mode: nil; -*-

// we only include RcppArmadillo.h which pulls Rcpp.h in for us
#include "RcppArmadillo.h"

#include <Rcpp.h>
#include <vector>

// [[Rcpp::depends(RcppArmadillo)]]

////////////////////////////////////////////////////////////////////////
//some functions for preparation
////////////////////////////////////////////////////////////////////////

// linear regression in Rcpp
// [[Rcpp::export]]
Rcpp::List fastLmV(const arma::mat& X, const arma::colvec& y, const int k){ 
    int n = X.n_rows; 
    
    arma::colvec coef = arma::solve(X, y);    // fit model y ~ X
    arma::colvec res  = y - X*coef;           // residuals
    
    // std.errors of coefficients
    double s2 = std::inner_product(res.begin(), res.end(), res.begin(), 0.0)/(n - k); // k is the number of covariates including intercept
    
    arma::colvec std_err = arma::sqrt(s2 * arma::diagvec(arma::pinv(arma::trans(X)*X)));
    
    arma::colvec t_value = coef/std_err; 
    return Rcpp::List::create(Rcpp::Named("coefficients") = coef,
                              Rcpp::Named("stderr")       = std_err,
                              Rcpp::Named("residuals")    = res,
                              Rcpp::Named("t.value")      = t_value);
}

////////////////////////////////////////////////////////////////////////
//function that does the innter bootstrap
////////////////////////////////////////////////////////////////////////
#include <RcppArmadilloExtensions/sample.h>
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::export]]
arma::uvec ind_sample( int n){
    arma::uvec uniind = arma::linspace<arma::uvec>(0, n-1, n); 
    arma::uvec unifnum = Rcpp::RcppArmadillo::sample(uniind, n, TRUE); //arma::uvec unifnum = randi<arma::uvec>( n, distr_param(0, n-1)); 
    return unifnum;
}


////////////////////////////////////////////////////////////////////////
//function that computes projection
////////////////////////////////////////////////////////////////////////
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::export()]]
arma::vec compute_projection(arma::mat proj_covariate, arma::vec response_var, const int k){
    Rcpp::List proj_lm = fastLmV(proj_covariate, response_var, k);  
    arma::vec proj_response = proj_lm["residuals"];
    return proj_response; 
}






