//Functions for generating data based on model and also with projection step

// -*- mode: C++; c-indent-level: 4; c-basic-offset: 4; indent-tabs-mode: nil; -*-

// we only include RcppArmadillo.h which pulls Rcpp.h in for us
#include "RcppArmadillo.h"
#include "rcpp_1_prepare.h"

#include <Rcpp.h>
#include <vector>

// [[Rcpp::depends(RcppArmadillo)]]

////////////////////////////////////////////////////////////////////////
//functions for data generation steps when there are covariates X
////////////////////////////////////////////////////////////////////////




////////////////////////////////////////////////////////////////////////
//1. build the model with X
////////////////////////////////////////////////////////////////////////
// [[Rcpp::export()]]
arma::mat gendata_model_X_C(int n,  const arma::vec& alpha_coef, const arma::vec& beta_coef, 
                               const arma::mat& mydata_tmp, const arma::mat& other_covariates, 
                               arma::vec coef_X_alpha, arma::vec coef_X_beta, double direct_effect, int num_med){
  
  int k_col = 2 + num_med;  //number of columns: S + m mediators + Y
  
  arma::mat Mydata_original( n, k_col );
  
  // int n_other = other_covariates.n_cols;
  
  //generate model from raw data
  arma::vec S_n = mydata_tmp.col(0);  //binary exposure
  Mydata_original.col(0) = S_n;
  
  //response Y to be generated from model
  arma::vec Y_tmp;
  Y_tmp.zeros(n);
  
  //loop over num_med mediators
  for(int ind_j = 0; ind_j < num_med; ind_j++){
    arma::vec M_tmp = S_n * alpha_coef(ind_j) + other_covariates * coef_X_alpha + mydata_tmp.col( 1 + ind_j); //j-th mediator variable
    Y_tmp =  Y_tmp + M_tmp * beta_coef(ind_j);
    
    //save original data in model
    Mydata_original.col( 1 + ind_j ) = M_tmp; //M_tmp;
  }
  
  //build original Y-M model
  Y_tmp = Y_tmp + S_n * direct_effect + other_covariates * coef_X_beta  + mydata_tmp.col( 1 + num_med ); //error term is the last column of the original data
  
  Mydata_original.col( 1 + num_med ) = Y_tmp; 
  
  return Mydata_original;
}
  
  




////////////////////////////////////////////////////////////////////////
//2. do the projection with X
////////////////////////////////////////////////////////////////////////

// [[Rcpp::export()]]
arma::mat gendata_proj_X_C(int n, const arma::mat& mydata, const arma::mat& other_covariates, int num_med){
  
  int k_col = 1 + 3 * num_med;  //number of columns: S + m mediators + m mediator_projected + Y m different projections
  
  arma::mat Mydata( n, k_col );
  
  int n_other = other_covariates.n_cols;
  
  //generate model from raw data
  arma::vec S_n = mydata.col(0);  //binary exposure
  arma::vec S_proj = compute_projection( other_covariates, S_n, n_other );
  Mydata.col(0) = S_proj;
  
  //loop over num_med mediators
  for(int ind_j = 0; ind_j < num_med; ind_j++){
    arma::vec M_tmp = mydata.col( 1 + ind_j ); 
    
    //projection in M-S model
    arma::vec M_proj_tmp_1 = compute_projection( other_covariates, M_tmp, n_other );
    
    //save projected data
    Mydata.col( 1 + ind_j ) = M_proj_tmp_1; //M_tmp;
  }
  
  //read original Y variable
  arma::vec Y_tmp = mydata.col( 1 + num_med ); //error term is the last column of the original data
  
  //projection in Y-M model
  int df_proj = num_med - 1 + n_other;
  for(int ind_j = 0; ind_j < num_med; ind_j++){
    
    //extract the covariates to be projected on
    arma::mat proj_covariate = join_rows( mydata.cols(1, num_med), S_n, other_covariates);  //read all mediators M and S + X
    arma::vec M_covariate = proj_covariate.col( ind_j ); //read one selected mediator
    proj_covariate.shed_col( ind_j );                    //delete readed mediator that does not project
    
    Mydata.col( num_med + 1 + ind_j ) = compute_projection( proj_covariate, M_covariate, df_proj );
    Mydata.col( num_med * 2 + 1 + ind_j ) = compute_projection( proj_covariate, Y_tmp, df_proj );
  }
  
  //Mydata column (0): S_proj; (1)-(m) M_proj in M-S model; (m+1)-(2m) M proj in Y-M Model + (2m+1)-(3m) Y proj in Y-M model
  return Mydata;
  
}










