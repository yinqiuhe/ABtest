//
//  rcpp_2_data_gen_X.h
//  
//
//  Created by Y H on 9/10/21.
//

#ifndef rcpp_2_data_gen_X_h
#define rcpp_2_data_gen_X_h

arma::mat gendata_model_X_C(int n,  const arma::vec& alpha_coef, const arma::vec& beta_coef, 
                            const arma::mat& mydata_tmp, const arma::mat& other_covariates, 
                            arma::vec coef_X_alpha, arma::vec coef_X_beta, double direct_effect, int num_med);

arma::mat gendata_proj_X_C(int n, const arma::mat& mydata, const arma::mat& other_covariates, int num_med);

#endif /* rcpp_2_data_gen_X_h */
