//
//  rcpp_5_doubleBoot.h
//  
//
//  Created by Y H on 9/6/21.
//

#ifndef rcpp_5_doubleBoot_h
#define rcpp_5_doubleBoot_h

Rcpp::List doubleBoot_C(arma::mat mydata, double T_hat_all, int n,  int num_other_alpha, int num_other_beta, 
                        int N_boot_out, int N_boot_in, 
                        arma::vec Z_alpha, arma::vec Z_beta, arma::mat res_alpha, arma::mat res_beta,
                        arma::vec Coef_alpha, arma::vec Coef_beta,
                        arma::vec alpha_coef, arma::vec beta_coef,
                        double lambda_n1, double lambda_n2, double omega, int num_med); 

#endif /* rcpp_5_doubleBoot_h */
