//
//  rcpp_5_doubleBoot_X_no_proj.h
//  
//
//  Created by Y H on 9/10/21.
//

#ifndef rcpp_5_doubleBoot_X_no_proj_h
#define rcpp_5_doubleBoot_X_no_proj_h

Rcpp::List doubleBoot_X_no_proj(arma::mat mydata, arma::mat other_covariates,
                                double T_hat_all, int n,  int num_other_alpha, int num_other_beta, 
                                int N_boot_out, int N_boot_in, 
                                arma::vec Z_alpha, arma::vec Z_beta, arma::mat res_alpha, arma::mat res_beta,
                                arma::vec Coef_alpha, arma::vec Coef_beta,
                                double lambda_n1, double lambda_n2, double omega, int num_med);

#endif /* rcpp_5_doubleBoot_X_no_proj_h */
