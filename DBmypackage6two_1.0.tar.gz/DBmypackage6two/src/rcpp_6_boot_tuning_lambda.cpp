#include "RcppArmadillo.h"
#include "rcpp_1_prepare.h"
#include "rcpp_2_data_gen.h"
#include "rcpp_2_data_gen_X.h"
#include "rcpp_3_compute_stat.h"
#include "rcpp_4_innerBoot.h"
#include "rcpp_5_doubleBoot_X_no_proj.h"

#include <Rcpp.h>
#include <vector>

// [[Rcpp::depends(RcppArmadillo)]]

////////////////////////////////////////////////////////////////////////
//function that computes projection
////////////////////////////////////////////////////////////////////////
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::export()]]
arma::mat compute_multi_proj(arma::mat proj_covariate, arma::mat response_var, const int k){
  //project a multivariate response to common covariates proj_covariate
  int n_dim = response_var.n_cols;
  int n_row = response_var.n_rows;
  arma::mat response_proj;
  response_proj.zeros(n_row, n_dim);
  
  for(int ind_j = 0; ind_j < n_dim; ind_j++){
    arma::vec response_var_j = response_var.col( ind_j );  //get original 
    arma::vec response_proj_j = compute_projection( proj_covariate, response_var_j, k ); //compute X_S
    response_proj.col(ind_j) = response_proj_j; 
  }
  return response_proj; 
}


////////////////////////////////////////////////////////////////////////////////////////
//function that does the bootstrap where we manually project variables with alpha_hat=0
////////////////////////////////////////////////////////////////////////////////////////
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::export()]]
Rcpp::List boot_tuning_par_C(const arma::mat& mydata_original, arma::mat& other_covariates, 
                             int n, double omega, int num_med,
                             double lambda_n1, double lambda_n2, 
                             int N_boot_out, int N_boot_in,
                             int num_other_alpha, int num_other_beta){
  //Part I. For alpha = 0
  //1.1 get projected data
  //pairwise bootstrap of (M_S ~ S + X_S), (Y ~ M + S + X)
  // (1.a) compute  M_S, X_S (Y model remains the same)
  arma::vec S_n = mydata_original.col(0);  //binary exposure
  arma::vec M_original = mydata_original.col(1);  //one mediator M
  arma::vec M_proj_S = compute_projection( S_n, M_original, 1 ); //compute M_S
  
  arma::mat X_proj_S = compute_multi_proj(S_n, other_covariates, 1); 
  
  // (2.a) combine to new data (M_S ~ S + X_S) (Y ~ M + S + X)
  arma::mat M_model_proj_S = join_rows( M_proj_S, S_n, X_proj_S);  
  arma::mat Y_model_original = join_rows(mydata_original, other_covariates); 
  
  //1.2 bootstrap: get resampling index, and get the bootstrapped statistic for each model
  //1.3 [2] project data to X (two models are done separately)
  //1.4 [3] old statistic computation function can still be used
  
  double Boot_inner_p_val_alpha = 0;
  double tmp_ind_inner_alpha = 0;
  
  arma::vec Boot_res_alpha_0(N_boot_out);
  arma::vec all_class_Boot_pval_alpha_0(N_boot_out);
  arma::mat Boot_alpha(N_boot_out, num_med);
  arma::mat Boot_beta(N_boot_out, num_med);
  
  //bootstrap loop
  for(int out_ind = 0; out_ind < N_boot_out; out_ind++){
    //1: get bootstrap sample for the outer loop
    arma::uvec unif_ind_out =  ind_sample(n);
    
    //Bootstrap M model
    arma::vec Boot_S_n = S_n(unif_ind_out); 
    arma::mat Boot_X_proj_S = X_proj_S.rows(unif_ind_out); 
    arma::vec Boot_M_proj_S = M_proj_S(unif_ind_out);
    //Bootstrap full original model and covariates X
    arma::mat Boot_mydata = mydata_original.rows(unif_ind_out);
    arma::mat Boot_X_cov_tmp = other_covariates.rows(unif_ind_out); 
      
    //compute projection over X
    //M model: M_{(S,X)}*, S_X* (use X_S* for projection)
    arma::vec Boot_M_proj_S_X = compute_projection(Boot_X_proj_S, Boot_M_proj_S, 2); //M_{(S,X)}*
    arma::vec Boot_Sn_proj_X = compute_projection(Boot_X_proj_S, Boot_S_n, 2); //S_X*
    
    //Y_model: Y_{(S,X)}*, M_{(S,X)}* (use X* for projection), use the old codes to compute
    arma::mat Boot_two_model_proj = gendata_proj_X_C(n, Boot_mydata, Boot_X_cov_tmp, num_med); 
    
    //this generates a data corresponding to Bootdata_outer in the olde codes
    //column (0): S_proj; (1)-(m) M_proj in M-S model; (m+1)-(2m) M proj in Y-M Model + (2m+1)-(3m) Y proj in Y-M model
    //For alpha case, we take (m+1)-(3m) columns
    
    //M model: perturb alpha = 0
    arma::mat Boot_alpha_0_Y_model = Boot_two_model_proj.cols( (num_med+1), (3*num_med) ); //read Y model from old codes
    arma::mat Boot_data_alpha_0 = join_rows(Boot_Sn_proj_X, Boot_M_proj_S_X, Boot_alpha_0_Y_model); //combine M and Y model
    //column (0): S_proj_X; (1)-(m) M_proj_S_X in M-S model; (m+1)-(2m) M proj in Y-M Model + (2m+1)-(3m) Y proj in Y-M model
    
    //III.2: compute bootstrap information: theta.hat.star, and coefficients.star, and Z statistics.star
    Rcpp::List tmp_star = computeTest_C(Boot_data_alpha_0, n, num_other_alpha, num_other_beta, num_med);
    double T_hat_star_alpha = tmp_star["T_hat_all"]; // get the bootstrap product test statistic
    // all_class_Boot(out_ind) = T_hat_star;      //save the classical bootstrapped product test statistic
    
    // Rcpp::Rcout << "T_hat_star_alpha: " << T_hat_star_alpha << std::endl;
    
    //III. 2.1: reading regression results, coefficients and Z statistics
    arma::vec BootZ_alpha = tmp_star["Z_alpha"];
    arma::vec BootZ_beta = tmp_star["Z_beta"];
    
    arma::vec BootCoef_alpha = tmp_star["Coef_alpha"];
    arma::vec BootCoef_beta = tmp_star["Coef_beta"];
    
    arma::mat Boot_res_alpha = tmp_star["res_alpha"];
    arma::mat Boot_res_beta = tmp_star["res_beta"];
    
    Boot_alpha.row( out_ind ) = BootCoef_alpha.t();
    Boot_beta.row( out_ind ) = BootCoef_beta.t();
    
    // arma::vec in_Boot_alpha_res(N_boot_in); 
    
    arma::vec all_class_Boot_alpha_0(N_boot_in);
    Boot_inner_p_val_alpha = 0;
    tmp_ind_inner_alpha = 0;
    
    //apply the adaptive bootstrap to the data after projection
    for(int out_ind_in = 0; out_ind_in < N_boot_in; out_ind_in++){
      arma::uvec unif_ind_out_in =  ind_sample(n);
      //bootstrap the bootstrapped data
      //Bootstrap M model
      arma::vec Boot_Boot_S_n = Boot_S_n(unif_ind_out_in); 
      arma::mat Boot_Boot_X_proj_S = Boot_X_proj_S.rows(unif_ind_out_in); 
      arma::vec Boot_Boot_M_proj_S = Boot_M_proj_S(unif_ind_out_in);
      //Bootstrap full original model and covariates X
      arma::mat Boot_Boot_mydata = Boot_mydata.rows(unif_ind_out_in);
      arma::mat Boot_Boot_X_cov_tmp = Boot_X_cov_tmp.rows(unif_ind_out_in); 
      //Generate a data Bootdata_inner (project out X variables)
      arma::vec Boot_Boot_M_proj_S_X = compute_projection(Boot_Boot_X_proj_S, Boot_Boot_M_proj_S, 2); //M_{(S,X)}*
      arma::vec Boot_Boot_Sn_proj_X = compute_projection(Boot_Boot_X_proj_S, Boot_Boot_S_n, 2); //S_X*
      arma::mat Boot_Boot_two_model_proj = gendata_proj_X_C(n, Boot_Boot_mydata, Boot_Boot_X_cov_tmp, num_med); 
      
      //M model: perturb alpha = 0 boot inner version
      arma::mat Boot_Boot_alpha_0_Y_model = Boot_Boot_two_model_proj.cols( (num_med+1), (3*num_med) ); //read Y model from old codes
      arma::mat Boot_Boot_data_alpha_0 = join_rows(Boot_Boot_Sn_proj_X, Boot_Boot_M_proj_S_X, Boot_Boot_alpha_0_Y_model); //combine M and Y model
      
      
      //Compute bootstrap statistics
      Rcpp::List Boot_tmp_star = computeTest_C(Boot_Boot_data_alpha_0, n, num_other_alpha, num_other_beta, num_med);
      double Boot_T_hat_star_alpha = Boot_tmp_star["T_hat_all"]; // get the bootstrap product test statistic
      all_class_Boot_alpha_0(out_ind_in) = Boot_T_hat_star_alpha;
      
      //III. 2.1: reading regression results, coefficients and Z statistics
      arma::vec Boot_BootZ_alpha = Boot_tmp_star["Z_alpha"];
      arma::vec Boot_BootZ_beta = Boot_tmp_star["Z_beta"];
      
      arma::vec Boot_BootCoef_alpha = Boot_tmp_star["Coef_alpha"];
      arma::vec Boot_BootCoef_beta = Boot_tmp_star["Coef_beta"];
      
      arma::mat Boot_Boot_res_alpha = Boot_tmp_star["res_alpha"];
      arma::mat Boot_Boot_res_beta = Boot_tmp_star["res_beta"];
      
      
      //III. 3: compute one bootstrap statistic with thresholding: lm from original data is passed to get the residuals
      double Boot_res_one_alpha = ThresOnebootComp_C(n, num_other_alpha, num_other_beta, Boot_Boot_data_alpha_0, 
                                                     T_hat_star_alpha, Boot_T_hat_star_alpha, unif_ind_out_in, num_med,
                                                     BootZ_alpha, BootZ_beta, Boot_res_alpha, Boot_res_beta, 
                                                     Boot_BootZ_alpha, Boot_BootZ_beta, 
                                                     Boot_BootCoef_alpha, Boot_BootCoef_beta, 
                                                     Boot_Boot_res_alpha, Boot_Boot_res_beta,
                                                     lambda_n1, lambda_n2);
      
      
      // Rcpp::Rcout << "Boot_res_one_alpha: " << Boot_res_one_alpha << std::endl;
      
      // tmp_ind_inner_alpha = (Boot_res_one_alpha > (T_hat_star_alpha - 0));
      tmp_ind_inner_alpha = (Boot_res_one_alpha > 0);
      Boot_inner_p_val_alpha = Boot_inner_p_val_alpha + tmp_ind_inner_alpha; //conv_to<double>::from(tmp_ind_inner);
    }
    
    // Rcpp::Rcout << "Boot_inner_p_val_alpha: " << Boot_inner_p_val_alpha << std::endl;
    
    Boot_inner_p_val_alpha =  Boot_inner_p_val_alpha / N_boot_in;
    double Boot_inner_p_val_alpha2 = 2 * min( Rcpp::NumericVector::create( Boot_inner_p_val_alpha, (1-Boot_inner_p_val_alpha) ) );
    Boot_res_alpha_0(out_ind) = Boot_inner_p_val_alpha2;

    // double tmp_p_val_class2_alpha_0 = mean(arma::conv_to<arma::vec>::from( all_class_Boot_alpha_0 > 0) );
    double tmp_p_val_class2_alpha_0 = mean(arma::conv_to<arma::vec>::from( (all_class_Boot_alpha_0 - T_hat_star_alpha) > (T_hat_star_alpha - 0)) );
    double p_val_class_alpha_0 = 2 * min( Rcpp::NumericVector::create( tmp_p_val_class2_alpha_0, (1- tmp_p_val_class2_alpha_0) ) );
    all_class_Boot_pval_alpha_0(out_ind) = p_val_class_alpha_0;
    
  }
  
  return Rcpp::List::create(Rcpp::Named("Boot_res_alpha_0") = Boot_res_alpha_0,
                            Rcpp::Named("Boot_res_class_alpha_0") = all_class_Boot_pval_alpha_0);
}




////////////////////////////////////////////////////////////////////////////////////////
//function that does the bootstrap where we manually project variables with alpha_hat=0
////////////////////////////////////////////////////////////////////////////////////////
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::export()]]
Rcpp::List boot_tuning_par_two_C(const arma::mat& mydata_original, arma::mat& other_covariates, 
                                 int n, double omega, int num_med,
                                 double lambda_n1_alpha, double lambda_n2_alpha, 
                                 double lambda_n1_beta, double lambda_n2_beta, 
                                 double lambda_n1_both, double lambda_n2_both, 
                                 int N_boot_out, int N_boot_in,
                                 int num_other_alpha, int num_other_beta){
  //lambda_n1_alpha and lambda_n2_alpha are for alpha=0
  //lambda_n1_beta and lambda_n2_beta are for beta=0
  //Part I. For alpha = 0
  //1.1 get projected data
  //pairwise bootstrap of (M_S ~ S + X_S), (Y ~ M + S + X)
  // (1.a) compute  M_S, X_S (Y model remains the same)
  arma::vec S_n = mydata_original.col(0);  //binary exposure
  arma::vec M_original = mydata_original.col(1);  //one mediator M
  arma::vec M_proj_S = compute_projection( S_n, M_original, 1 ); //compute M_S
  arma::mat X_proj_S = compute_multi_proj(S_n, other_covariates, 1); //compute X_S
  
  //pairwise bootstrap of (Y_M ~ S_M + X_M + M)
  //(1.b) compute Y_M, (M model remains the same)
  arma::vec Y_n = mydata_original.col(num_med+1);
  arma::vec M_n = mydata_original.col(num_med); 
  arma::vec Y_proj_M = compute_projection( M_n, Y_n, 1 ); //compute Y_M
  arma::vec S_proj_M = compute_projection( M_n, S_n, 1 ); //compute Y_M
  arma::mat X_proj_M = compute_multi_proj( M_n, other_covariates, 1 );
  
  
  // (2.a) combine to new data (M_S ~ S + X_S) (Y ~ M + S + X)
  arma::mat M_model_proj_S = join_rows( M_proj_S, S_n, X_proj_S);  
  
  // (2.b) combine to new data (M ~ S + X) (Y_M ~ M + S_M + X_M)
  arma::mat Y_model_proj_M = join_rows( M_n, S_n, other_covariates);
  
  // (2.c) combine original data and X covariates
  arma::mat Y_model_original = join_rows(mydata_original, other_covariates); 
  
  
  //1.2 bootstrap: get resampling index, and get the bootstrapped statistic for each model
  //1.3 [2] project data to X (two models are done separately)
  //1.4 [3] old statistic computation function can still be used
    
  double Boot_inner_p_val_alpha = 0;
  double tmp_ind_inner_alpha = 0;
  arma::vec Boot_res_alpha_0(N_boot_out);
  arma::vec all_class_Boot_pval_alpha_0(N_boot_out);
  
  double Boot_inner_p_val_beta = 0;
  double tmp_ind_inner_beta = 0;
  arma::vec Boot_res_beta_0(N_boot_out);
  arma::vec all_class_Boot_pval_beta_0(N_boot_out);
  
  double Boot_inner_p_val_both = 0;
  double tmp_ind_inner_both = 0;
  arma::vec Boot_res_both_0(N_boot_out);
  arma::vec all_class_Boot_pval_both_0(N_boot_out);
  
    
    //******for testing results, can be deleted later
    arma::mat mydata = gendata_proj_X_C(n, mydata_original, other_covariates, num_med); //compute the projected data
    Rcpp::List tmp = computeTest_C(mydata, n, num_other_alpha, num_other_beta, num_med);
    arma::vec Coef_alpha = tmp["Coef_alpha"];
    arma::vec Coef_beta = tmp["Coef_beta"];
    //******for testing results, can be deleted later
    
    //******for testing results, can be deleted later
    arma::vec all_BootZ_alpha(N_boot_out);
    arma::vec all_BootZ_beta(N_boot_out);
    arma::vec all_BootZ_alpha_2(N_boot_out);
    arma::vec all_BootZ_beta_2(N_boot_out);
    arma::vec all_BootZ_alpha_both(N_boot_out);
    arma::vec all_BootZ_beta_both(N_boot_out);
    
    arma::vec all_BootZ_alpha0_alpha(N_boot_out);
    arma::vec all_BootZ_alpha0_beta(N_boot_out);
    arma::vec all_BootZ_alpha0_pod(N_boot_out);
    arma::vec all_BootZ_alpha0_stat(N_boot_out);
    arma::vec all_BootZ_alpha0_statp(N_boot_out);
    
    arma::vec all_Coef_alpha0_alpha(N_boot_out);
    arma::vec all_Coef_alpha0_beta(N_boot_out);
    arma::vec all_alpha0_Zalpha(N_boot_out);
    arma::vec all_alpha0_Zbeta(N_boot_out);
    arma::vec all_count_num_ind(N_boot_out);
    //******for testing results, can be deleted later
    
    
  //bootstrap loop
  for(int out_ind = 0; out_ind < N_boot_out; out_ind++){
    //1: get bootstrap sample for the outer loop
    arma::uvec unif_ind_out =  ind_sample(n);
    
    //(1) Bootstrap M model (after projection on S)
    arma::vec Boot_S_n = S_n(unif_ind_out); 
    arma::mat Boot_X_proj_S = X_proj_S.rows(unif_ind_out); 
    arma::vec Boot_M_proj_S = M_proj_S(unif_ind_out);
    //(2) Bootstrap Y model (after projection on M)
    arma::vec Boot_M_n = M_n(unif_ind_out);
    arma::vec Boot_Y_proj_M = Y_proj_M(unif_ind_out);
    arma::vec Boot_S_proj_M = S_proj_M(unif_ind_out);
    arma::mat Boot_X_proj_M = X_proj_M.rows(unif_ind_out);
    
    //(3) Bootstrap full original model and covariates X
    arma::mat Boot_mydata = mydata_original.rows(unif_ind_out);
    arma::mat Boot_X_cov_tmp = other_covariates.rows(unif_ind_out); 
    
    //Part I. construction of data 
    /////// (a) alpha = 0 part ///////
    //1.compute projection over X
    //M model: M_{(S,X)}*, S_X* (use X_S* for projection)
    arma::vec Boot_M_proj_S_X = compute_projection(Boot_X_proj_S, Boot_M_proj_S, 2); //M_{(S,X)}*
    arma::vec Boot_Sn_proj_X = compute_projection(Boot_X_proj_S, Boot_S_n, 2); //S_X*
    
    //Y_model: Y_{(S,X)}*, M_{(S,X)}* (use X* for projection), use the old codes to compute
    arma::mat Boot_two_model_proj = gendata_proj_X_C(n, Boot_mydata, Boot_X_cov_tmp, num_med); 
    
    //this generates a data corresponding to Bootdata_outer in the olde codes
    //column (0): S_proj; (1)-(m) M_proj in M-S model; (m+1)-(2m) M proj in Y-M Model + (2m+1)-(3m) Y proj in Y-M model
    //For alpha case, we take (m+1)-(3m) columns
    
    //M model: perturb alpha = 0
    arma::mat Boot_alpha_0_Y_model = Boot_two_model_proj.cols( (num_med+1), (3*num_med) ); //read Y model from old codes
    arma::mat Boot_data_alpha_0 = join_rows(Boot_Sn_proj_X, Boot_M_proj_S_X, Boot_alpha_0_Y_model); //combine M and Y model
    //column (0): S_proj_X; (1)-(m) M_proj_S_X in M-S model; (m+1)-(2m) M proj in Y-M Model + (2m+1)-(3m) Y proj in Y-M model
    
    /////// (b) beta = 0 part///////
    //1. compute projection over X
    //Y model: Y_{(M,S,X)}*, M_{(S,X)}* (use (S_M*, X_M*) for projection)
    arma::mat tmp_boot_join_S_X = join_rows(Boot_S_proj_M, Boot_X_proj_M); //joint (S_M*, X_M*)
    arma::vec Boot_Y_proj_M_S_X = compute_projection(tmp_boot_join_S_X, Boot_Y_proj_M, 1);
    arma::vec Boot_M_proj_S_X_proj_M = compute_projection(tmp_boot_join_S_X, Boot_M_n, 1); 
    //different from Boot_M_proj_S_X because we use  (S_M*, X_M*)
      
    //M model: M_{(X)}*, S_{X}* (use X* for projection, read directly from old codes)
    arma::mat Boot_beta_0_M_model = Boot_two_model_proj.cols(0, num_med);
    
    //Combine M, Y models when beta=0
    arma::mat Boot_data_beta_0 = join_rows(Boot_beta_0_M_model, Boot_M_proj_S_X_proj_M, Boot_Y_proj_M_S_X);
    //column (0): S_{X}*; (1)-(m) M_{X}* in M-S model; (m+1)-(2m) M_{(S,X)}* (beta) in Y-M model; (2m+1)-(3m) Y_{(M,S,X)}*
 
    /////// (c) alpha=beta=0 ///////  
    arma::mat Boot_data_alpha_0_beta_0 = join_rows(Boot_Sn_proj_X, Boot_M_proj_S_X, Boot_M_proj_S_X_proj_M, Boot_Y_proj_M_S_X);
 
    //Part II: compute bootstrap information: theta.hat.star, and coefficients.star, and Z statistics.star
    // (a.1) Outerbootstrap results when alpha=0
    Rcpp::List tmp_star = computeTest_C(Boot_data_alpha_0, n, num_other_alpha, num_other_beta, num_med);
    double T_hat_star_alpha = tmp_star["T_hat_all"]; // get the bootstrap product test statistic
    // all_class_Boot(out_ind) = T_hat_star;      //save the classical bootstrapped product test statistic
    
    // Rcpp::Rcout << "T_hat_star_alpha: " << T_hat_star_alpha << std::endl;
    
    // (a.2) read regression results, coefficients and Z statistics obtained when alpha=0
    arma::vec BootZ_alpha = tmp_star["Z_alpha"];
    arma::vec BootZ_beta = tmp_star["Z_beta"];
    
    arma::vec BootCoef_alpha = tmp_star["Coef_alpha"];
    arma::vec BootCoef_beta = tmp_star["Coef_beta"];
    
    arma::mat Boot_res_alpha = tmp_star["res_alpha"];
    arma::mat Boot_res_beta = tmp_star["res_beta"];
    
      //******for testing results, can be deleted later
      all_BootZ_alpha0_stat(out_ind) = T_hat_star_alpha;
      all_BootZ_alpha0_statp(out_ind) = BootCoef_alpha(0) * BootCoef_beta(0);
      all_Coef_alpha0_alpha(out_ind) = BootCoef_alpha(0);
      all_Coef_alpha0_beta(out_ind) = BootCoef_beta(0);
      all_alpha0_Zalpha(out_ind) = BootZ_alpha(0);
      all_alpha0_Zbeta(out_ind) = BootZ_beta(0);
      //******for testing results, can be deleted later
      
    //(a.3) alpha=0: for saving results from inner bootstrap
    arma::vec all_class_Boot_alpha_0(N_boot_in);
    Boot_inner_p_val_alpha = 0;
    tmp_ind_inner_alpha = 0;
    
    //(b.1) Outer bootstrap results when beta=0
    Rcpp::List tmp_star_beta = computeTest_C(Boot_data_beta_0, n, num_other_alpha, num_other_beta, num_med );
    double T_hat_star_beta = tmp_star_beta["T_hat_all"];
    
    //(b.2) reading regression results, coefficients and Z statistics obtained when beta=0
    arma::vec BootZ_alpha_2 = tmp_star_beta["Z_alpha"];
    arma::vec BootZ_beta_2 = tmp_star_beta["Z_beta"];
    
    arma::vec BootCoef_alpha_2 = tmp_star_beta["Coef_alpha"];
    arma::vec BootCoef_beta_2 = tmp_star_beta["Coef_beta"];
    
    arma::mat Boot_res_alpha_2 = tmp_star_beta["res_alpha"];
    arma::mat Boot_res_beta_2 = tmp_star_beta["res_beta"];
    
    //(b.3) beta=0; for saving results from inner bootstrap
    arma::vec all_class_Boot_beta_0(N_boot_in);
    Boot_inner_p_val_beta = 0;
    tmp_ind_inner_beta = 0;
    
    //(c.1) Outer bootstrap results when alpha=beta=0
    Rcpp::List tmp_star_both = computeTest_C(Boot_data_alpha_0_beta_0, n, num_other_alpha, num_other_beta, num_med );
    double T_hat_star_both = tmp_star_both["T_hat_all"];
    
    //(c.2) reading regression results, coefficients and Z statistics obtained when alpha=beta=0
    arma::vec BootZ_alpha_both = tmp_star_both["Z_alpha"];
    arma::vec BootZ_beta_both = tmp_star_both["Z_beta"];
    
    arma::vec BootCoef_alpha_both = tmp_star_both["Coef_alpha"];
    arma::vec BootCoef_beta_both = tmp_star_both["Coef_beta"];
    
    arma::mat Boot_res_alpha_both = tmp_star_both["res_alpha"];
    arma::mat Boot_res_beta_both = tmp_star_both["res_beta"];
    
    //(c.3) alpha=beta=0; for saving results from inner bootstrap
    arma::vec all_class_Boot_both_0(N_boot_in);
    Boot_inner_p_val_both = 0;
    tmp_ind_inner_both = 0;
    
    //******for testing results, can be deleted later
    all_BootZ_alpha(out_ind) = BootZ_alpha(0);
    all_BootZ_beta(out_ind) = BootZ_beta(0);
    all_BootZ_alpha_2(out_ind) = BootZ_alpha_2(0);
    all_BootZ_beta_2(out_ind) = BootZ_beta_2(0);
    all_BootZ_alpha_both(out_ind) = BootZ_alpha_both(0);
    all_BootZ_beta_both(out_ind) = BootZ_beta_both(0);
    //******for testing results, can be deleted later
      
          //******for testing results, can be deleted later
          arma::vec Boot_all_BootZ_alpha(N_boot_in);
          arma::vec Boot_all_BootZ_beta(N_boot_in);
          arma::vec Boot_all_BootZ_alpha_2(N_boot_in);
          arma::vec Boot_all_BootZ_beta_2(N_boot_in);
          arma::vec Boot_all_BootZ_alpha_both(N_boot_in);
          arma::vec Boot_all_BootZ_beta_both(N_boot_in);
      
          double count_num_ind = 0;
          //******for testing results, can be deleted later
      
    //apply the adaptive bootstrap to the data after projection
    for(int out_ind_in = 0; out_ind_in < N_boot_in; out_ind_in++){
      arma::uvec unif_ind_out_in =  ind_sample(n);
      //(a.1) bootstrap the bootstrapped data when alpha=0
      //Bootstrap M model
      arma::vec Boot_Boot_S_n = Boot_S_n(unif_ind_out_in); 
      arma::mat Boot_Boot_X_proj_S = Boot_X_proj_S.rows(unif_ind_out_in); 
      arma::vec Boot_Boot_M_proj_S = Boot_M_proj_S(unif_ind_out_in);
      //Bootstrap full original model and covariates X
      arma::mat Boot_Boot_mydata = Boot_mydata.rows(unif_ind_out_in);
      arma::mat Boot_Boot_X_cov_tmp = Boot_X_cov_tmp.rows(unif_ind_out_in); 
      //Generate a data Bootdata_inner (project out X variables)
      arma::vec Boot_Boot_M_proj_S_X = compute_projection(Boot_Boot_X_proj_S, Boot_Boot_M_proj_S, 2); //M_{(S,X)}*
      arma::vec Boot_Boot_Sn_proj_X = compute_projection(Boot_Boot_X_proj_S, Boot_Boot_S_n, 2); //S_X*
      arma::mat Boot_Boot_two_model_proj = gendata_proj_X_C(n, Boot_Boot_mydata, Boot_Boot_X_cov_tmp, num_med); 
      
      //M model: perturb alpha = 0 boot inner version
      arma::mat Boot_Boot_alpha_0_Y_model = Boot_Boot_two_model_proj.cols( (num_med+1), (3*num_med) ); //read Y model from old codes
      arma::mat Boot_Boot_data_alpha_0 = join_rows(Boot_Boot_Sn_proj_X, Boot_Boot_M_proj_S_X, Boot_Boot_alpha_0_Y_model); //combine M and Y model
      
      //(a.2) Compute bootstrap statistics for alpha=0
      Rcpp::List Boot_tmp_star = computeTest_C(Boot_Boot_data_alpha_0, n, num_other_alpha, num_other_beta, num_med);
      double Boot_T_hat_star_alpha = Boot_tmp_star["T_hat_all"]; // get the bootstrap product test statistic
      all_class_Boot_alpha_0(out_ind_in) = Boot_T_hat_star_alpha;
      
      // Rcpp::Rcout << "Boot_T_hat_star_alpha: " << Boot_T_hat_star_alpha << std::endl;
      // Rcpp::Rcout << "Boot_T_hat_star_alpha-T_hat_star_alpha: " << Boot_T_hat_star_alpha-T_hat_star_alpha << std::endl;
      
      //(a.3) reading regression results, coefficients and Z statistics when alpha=0
      arma::vec Boot_BootZ_alpha = Boot_tmp_star["Z_alpha"];
      arma::vec Boot_BootZ_beta = Boot_tmp_star["Z_beta"];
      
      arma::vec Boot_BootCoef_alpha = Boot_tmp_star["Coef_alpha"];
      arma::vec Boot_BootCoef_beta = Boot_tmp_star["Coef_beta"];
      
      arma::mat Boot_Boot_res_alpha = Boot_tmp_star["res_alpha"];
      arma::mat Boot_Boot_res_beta = Boot_tmp_star["res_beta"];
      
        
            //******for testing results, can be deleted later
            Boot_all_BootZ_alpha(out_ind_in) = Boot_BootCoef_alpha(0);
            Boot_all_BootZ_beta(out_ind_in) = Boot_BootCoef_beta(0);
            //******for testing results, can be deleted later
        
      //(a.4) compute one bootstrap statistic with thresholding: lm from original data is passed to get the residuals
      double Boot_res_one_alpha = ThresOnebootComp_C_1(n, num_other_alpha, num_other_beta, Boot_Boot_data_alpha_0,
                                                       T_hat_star_alpha, Boot_T_hat_star_alpha, unif_ind_out_in, num_med,
                                                       BootZ_alpha, BootZ_beta, Boot_res_alpha, Boot_res_beta,
                                                       Boot_BootZ_alpha, Boot_BootZ_beta,
                                                       Boot_BootCoef_alpha, Boot_BootCoef_beta,
                                                       Boot_Boot_res_alpha, Boot_Boot_res_beta,
                                                       lambda_n1_alpha, lambda_n2_alpha);
      
      //tmp_ind_inner_alpha = (Boot_res_one_alpha > (T_hat_star_alpha - 0));
      tmp_ind_inner_alpha = (Boot_res_one_alpha > 0 );
      Boot_inner_p_val_alpha = Boot_inner_p_val_alpha + tmp_ind_inner_alpha; //conv_to<double>::from(tmp_ind_inner);
      
      //(b.1) bootstrap the bootstrapped data when beta=0
      //Bootstrap Y model
      arma::vec Boot_Boot_M_n = Boot_M_n(unif_ind_out_in); //M**
      arma::vec Boot_Boot_Y_proj_M = Boot_Y_proj_M(unif_ind_out_in); //Y_M**
      arma::vec Boot_Boot_S_proj_M = Boot_S_proj_M(unif_ind_out_in); //S_M**
      arma::mat Boot_Boot_X_proj_M = Boot_X_proj_M.rows(unif_ind_out_in); //X_M**
      arma::mat joint_Boot_Boot_S_X_proj_M = join_rows(Boot_Boot_S_proj_M, Boot_Boot_X_proj_M); //(S_M**,X_M**) joint
      
      //Generate a data Bootdata_inner (project out X variables)
      arma::vec Boot_Boot_Y_proj_S_X = compute_projection(joint_Boot_Boot_S_X_proj_M, Boot_Boot_Y_proj_M, 2); //M_{(S,X)}*
      arma::vec Boot_Boot_M_n_proj_S_X = compute_projection(joint_Boot_Boot_S_X_proj_M, Boot_Boot_M_n, 2); //S_X*
      
      //M model: perturb alpha = 0 boot inner version
      arma::mat Boot_Boot_beta_0_M_model = Boot_Boot_two_model_proj.cols( 0, num_med ); //read Y model from old codes
      arma::mat Boot_Boot_data_beta_0 = join_rows(Boot_Boot_beta_0_M_model, Boot_Boot_M_n_proj_S_X, Boot_Boot_Y_proj_S_X); //combine M and Y model
      
      //(b.2) Compute bootstrap statistics for beta=0
      Rcpp::List Boot_tmp_star_beta = computeTest_C(Boot_Boot_data_beta_0, n, num_other_alpha, num_other_beta, num_med);
      double Boot_T_hat_star_beta = Boot_tmp_star_beta["T_hat_all"];
      all_class_Boot_beta_0(out_ind_in) = Boot_T_hat_star_beta;
      
      //(b.3): reading regression results, coefficients and Z statistics
      arma::vec Boot_BootZ_alpha_2 = Boot_tmp_star_beta["Z_alpha"];
      arma::vec Boot_BootZ_beta_2 = Boot_tmp_star_beta["Z_beta"];
      
      arma::vec Boot_BootCoef_alpha_2 = Boot_tmp_star_beta["Coef_alpha"];
      arma::vec Boot_BootCoef_beta_2 = Boot_tmp_star_beta["Coef_beta"];
      
      arma::mat Boot_Boot_res_alpha_2 = Boot_tmp_star_beta["res_alpha"];
      arma::mat Boot_Boot_res_beta_2 = Boot_tmp_star_beta["res_beta"];
      
      //(b.4) compute one bootstrap statistic with thresholding: lm from original data is passed to get the residuals
      double Boot_res_one_beta = ThresOnebootComp_C_1(n, num_other_alpha, num_other_beta, Boot_Boot_data_beta_0,
                                                    T_hat_star_beta, Boot_T_hat_star_beta, unif_ind_out_in, num_med,
                                                    BootZ_alpha_2, BootZ_beta_2, Boot_res_alpha_2, Boot_res_beta_2, 
                                                    Boot_BootZ_alpha_2, Boot_BootZ_beta_2, 
                                                    Boot_BootCoef_alpha_2, Boot_BootCoef_beta_2, 
                                                    Boot_Boot_res_alpha_2, Boot_Boot_res_beta_2,
                                                    lambda_n1_beta, lambda_n2_beta);
      
      //tmp_ind_inner_beta = (Boot_res_one_beta > (T_hat_star_beta - 0));
      tmp_ind_inner_beta = (Boot_res_one_beta > 0 );
      Boot_inner_p_val_beta = Boot_inner_p_val_beta + tmp_ind_inner_beta; //conv_to<double>::from(tmp_ind_inner);

      
      //(c.1) bootstrap the bootstrapped data when alpha=beta=0, this can use the already bootstrapped from the previous two steps
      arma::mat Boot_Boot_data_both_0 = join_rows(Boot_Boot_Sn_proj_X, Boot_Boot_M_proj_S_X, Boot_Boot_M_n_proj_S_X, Boot_Boot_Y_proj_S_X); //combine M and Y model
      //Boot_Boot_Sn_proj_X and Boot_Boot_M_proj_S_X are computed when setting alpha=0
      //Boot_Boot_Y_proj_S_X and Boot_Boot_M_n_proj_S_X are computed when setting beta=0
      
      //(c.2) Compute bootstrap statistics when alpha=beta=0
      Rcpp::List Boot_tmp_star_both = computeTest_C(Boot_Boot_data_both_0, n, num_other_alpha, num_other_beta, num_med);
      double Boot_T_hat_star_both = Boot_tmp_star_both["T_hat_all"];
      all_class_Boot_both_0(out_ind_in) = Boot_T_hat_star_both;
      
      //(c.3): reading regression results, coefficients and Z statistics in the innerboot
      arma::vec Boot_BootZ_alpha_both = Boot_tmp_star_both["Z_alpha"];
      arma::vec Boot_BootZ_beta_both = Boot_tmp_star_both["Z_beta"];
      
      arma::vec Boot_BootCoef_alpha_both = Boot_tmp_star_both["Coef_alpha"];
      arma::vec Boot_BootCoef_beta_both = Boot_tmp_star_both["Coef_beta"];
      
      arma::mat Boot_Boot_res_alpha_both = Boot_tmp_star_both["res_alpha"];
      arma::mat Boot_Boot_res_beta_both = Boot_tmp_star_both["res_beta"];
      
      //(c.4) compute one bootstrap statistic with thresholding: lm from original data is passed to get the residuals
      double Boot_res_one_both = ThresOnebootComp_C_1(n, num_other_alpha, num_other_beta, Boot_Boot_data_both_0,
                                                    T_hat_star_both, Boot_T_hat_star_both, unif_ind_out_in, num_med,
                                                    BootZ_alpha_both, BootZ_beta_both, Boot_res_alpha_both, Boot_res_beta_both, 
                                                    Boot_BootZ_alpha_both, Boot_BootZ_beta_both, 
                                                    Boot_BootCoef_alpha_both, Boot_BootCoef_beta_both, 
                                                    Boot_Boot_res_alpha_both, Boot_Boot_res_beta_both,
                                                    lambda_n1_both, lambda_n2_both);
      
      //tmp_ind_inner_both = (Boot_res_one_both > (T_hat_star_both - 0));
      tmp_ind_inner_both = (Boot_res_one_both > 0);
      Boot_inner_p_val_both = Boot_inner_p_val_both + tmp_ind_inner_both;
        
        //******for testing results, can be deleted later
        double tmp_count_num_ind = ThresOnebootComp_C_2(n, num_other_alpha, num_other_beta, Boot_Boot_data_both_0,
                                                      T_hat_star_both, Boot_T_hat_star_both, unif_ind_out_in, num_med,
                                                      BootZ_alpha_both, BootZ_beta_both, Boot_res_alpha_both, Boot_res_beta_both,
                                                      Boot_BootZ_alpha_both, Boot_BootZ_beta_both,
                                                      Boot_BootCoef_alpha_both, Boot_BootCoef_beta_both,
                                                      Boot_Boot_res_alpha_both, Boot_Boot_res_beta_both,
                                                      lambda_n1_both, lambda_n2_both);
        count_num_ind = count_num_ind + tmp_count_num_ind;
        //******for testing results, can be deleted later
      
    }
      
    // (a) p-values when alpha=0
    Boot_inner_p_val_alpha =  Boot_inner_p_val_alpha / N_boot_in;
    double Boot_inner_p_val_alpha2 = 2 * min( Rcpp::NumericVector::create( Boot_inner_p_val_alpha, (1-Boot_inner_p_val_alpha) ) );
    Boot_res_alpha_0(out_ind) = Boot_inner_p_val_alpha2;
    
    // double tmp_p_val_class2_alpha_0 = mean(arma::conv_to<arma::vec>::from( all_class_Boot_alpha_0 > 0) );
    // double tmp_p_val_class2_alpha_0 = mean(arma::conv_to<arma::vec>::from( (all_class_Boot_alpha_0 - T_hat_star_alpha) > (T_hat_star_alpha - 0)) );
    double tmp_p_val_class2_alpha_0 = mean(arma::conv_to<arma::vec>::from( (all_class_Boot_alpha_0 ) > (2*T_hat_star_alpha - 0)) );
      
    double p_val_class_alpha_0 = 2 * min( Rcpp::NumericVector::create( tmp_p_val_class2_alpha_0, (1- tmp_p_val_class2_alpha_0) ) );
    
      //******for testing results, can be deleted later
      //p_val_class_alpha_0 = tmp_p_val_class2_alpha_0;
      //******for testing results, can be deleted later
      
    all_class_Boot_pval_alpha_0(out_ind) = p_val_class_alpha_0;
    
    // (b) p-values when beta=0
    Boot_inner_p_val_beta =  Boot_inner_p_val_beta / N_boot_in;
    double Boot_inner_p_val_beta2 = 2 * min( Rcpp::NumericVector::create( Boot_inner_p_val_beta, (1-Boot_inner_p_val_beta) ) );
    Boot_res_beta_0(out_ind) = Boot_inner_p_val_beta2;
    
    double tmp_p_val_class2_beta_0 = mean(arma::conv_to<arma::vec>::from( (all_class_Boot_beta_0 - T_hat_star_beta) > (T_hat_star_beta - 0)) );
    double p_val_class_beta_0 = 2 * min( Rcpp::NumericVector::create( tmp_p_val_class2_beta_0, (1- tmp_p_val_class2_beta_0) ) );
    all_class_Boot_pval_beta_0(out_ind) = p_val_class_beta_0;
    
    // (c) p-values when alpha=beta=0
    Boot_inner_p_val_both =  Boot_inner_p_val_both / N_boot_in;
    double Boot_inner_p_val_both2 = 2 * min( Rcpp::NumericVector::create( Boot_inner_p_val_both, (1-Boot_inner_p_val_both) ) );
    Boot_res_both_0(out_ind) = Boot_inner_p_val_both2;
    
    double tmp_p_val_class2_both_0 = mean(arma::conv_to<arma::vec>::from( (all_class_Boot_both_0 - T_hat_star_both) > (T_hat_star_both - 0)) );
    double p_val_class_both_0 = 2 * min( Rcpp::NumericVector::create( tmp_p_val_class2_both_0, (1- tmp_p_val_class2_both_0) ) );
    all_class_Boot_pval_both_0(out_ind) = p_val_class_both_0;
    
        //******for testing results, can be deleted later
        all_count_num_ind(out_ind) = count_num_ind;
      
        double tmp_p_val_alpha_0_alpha = mean(arma::conv_to<arma::vec>::from( Boot_all_BootZ_alpha > (2* BootCoef_alpha(0) - 0) ) );
        all_BootZ_alpha0_alpha(out_ind) = tmp_p_val_alpha_0_alpha;
        double tmp_p_val_alpha_0_beta = mean(arma::conv_to<arma::vec>::from( Boot_all_BootZ_beta > (2* BootCoef_beta(0) - Coef_beta(0)) ) );
        all_BootZ_alpha0_beta(out_ind) = tmp_p_val_alpha_0_beta;
        // arma::vec tmp_all_class_Boot_alpha_0_pod = all_class_Boot_alpha_0 - sqrt(n) * BootCoef_alpha(0) * BootCoef_beta(0);
        double tmp_p_val_alpha_0_pod = mean(arma::conv_to<arma::vec>::from( ((all_class_Boot_alpha_0)) > ( 0) ) );
//        double tmp_p_val_alpha_0_pod = mean(arma::conv_to<arma::vec>::from( (all_class_Boot_alpha_0 - BootCoef_alpha(0) * BootCoef_beta(0) ) > std::abs(BootCoef_alpha(0) * BootCoef_beta(0) - 0) ) );
//      all_BootZ_alpha0_pod(out_ind) = tmp_p_val_alpha_0_pod;
        all_BootZ_alpha0_pod(out_ind) = 2 * min( Rcpp::NumericVector::create( tmp_p_val_alpha_0_pod, (1- tmp_p_val_alpha_0_pod) ) );
        //tmp_p_val_alpha_0_pod;
        //******for testing results, can be deleted later
  }
  
  return Rcpp::List::create(Rcpp::Named("Boot_res_alpha_0") = Boot_res_alpha_0,
                            Rcpp::Named("Boot_res_class_alpha_0") = all_class_Boot_pval_alpha_0,
                            Rcpp::Named("Boot_res_beta_0") = Boot_res_beta_0,
                            Rcpp::Named("Boot_res_class_beta_0") = all_class_Boot_pval_beta_0,
                            Rcpp::Named("Boot_res_both_0") = Boot_res_both_0,
                            Rcpp::Named("Boot_res_class_both_0") = all_class_Boot_pval_both_0,
                            Rcpp::Named("all_BootZ_alpha") = all_BootZ_alpha0_alpha, //p-values of alpha coefficient
                            Rcpp::Named("all_BootZ_beta") = all_BootZ_alpha0_beta, //p-values of beta coefficient
                            Rcpp::Named("all_Coef_alpha0_alpha") = all_Coef_alpha0_alpha, //statistic
                            Rcpp::Named("all_Coef_alpha0_beta") = all_Coef_alpha0_beta, //statistic
                            Rcpp::Named("all_alpha0_Zalpha") = all_alpha0_Zalpha, //Z-stat
                            Rcpp::Named("all_alpha0_Zbeta") = all_alpha0_Zbeta, //Z-stat
                            Rcpp::Named("all_BootZ_alpha0_pod") = all_BootZ_alpha0_pod,
                            Rcpp::Named("all_BootZ_alpha0_stat") = all_BootZ_alpha0_stat,
                            Rcpp::Named("all_BootZ_alpha0_statp") = all_BootZ_alpha0_statp,
                            Rcpp::Named("all_count_num_ind") = all_count_num_ind,
                            Rcpp::Named("all_BootZ_alpha_2") = all_BootZ_alpha_2,
                            Rcpp::Named("all_BootZ_beta_2") = all_BootZ_beta_2,
                            Rcpp::Named("all_BootZ_alpha_both") = all_BootZ_alpha_both,
                            Rcpp::Named("all_BootZ_beta_both") = all_BootZ_beta_both);
}



