//Functions for generating data based on model and also with projection step

// -*- mode: C++; c-indent-level: 4; c-basic-offset: 4; indent-tabs-mode: nil; -*-

// we only include RcppArmadillo.h which pulls Rcpp.h in for us
#include "RcppArmadillo.h"
#include "rcpp_1_prepare.h"

#include <Rcpp.h>
#include <vector>

// [[Rcpp::depends(RcppArmadillo)]]

////////////////////////////////////////////////////////////////////////
//some functions for data generation steps
////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////
//1. function that generates basic data for building the model
////////////////////////////////////////////////////////////////////////
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::export()]]
arma::mat gendata_final_mult_simplified_C(int n,  const arma::vec& alpha_coef, const arma::vec& beta_coef, const arma::mat& mydata, int num_med){

  int k_col = 2 + num_med;      //number of columns: Y + S + multiple mediators
  arma::mat Mydata( n, k_col );
  
  //generate model from raw data
  arma::vec S_n = mydata.col(0); //exposure
  Mydata.col(0) = S_n; 
  arma::vec Y_tmp;
  Y_tmp.zeros(n); 
  
  for(int ind_j = 0; ind_j < num_med; ind_j++){
    arma::vec M_tmp = S_n * alpha_coef(ind_j) + mydata.col( 1 + ind_j); //j-th mediator variable 
    Mydata.col( 1 + ind_j ) = M_tmp;
    Y_tmp =  Y_tmp + M_tmp * beta_coef(ind_j); 
  }
  
  Mydata.col( (k_col-1) ) = Y_tmp + mydata.col( (k_col-1) ); //last column is the total column number minus 1 because starting from 0
  
  return Mydata;
}



////////////////////////////////////////////////////////////////////////
//2. function that generates data and preprocess with projection
////////////////////////////////////////////////////////////////////////
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::export()]]
arma::mat gendata_final_mult_simplified_proj_C(int n,  const arma::vec& alpha_coef, const arma::vec& beta_coef, 
                                               const arma::mat& mydata, int num_med){
  
  int k_col = 1 + 3 * num_med;  //number of columns: S + m mediators + m mediator_projected + Y m different projections
  
  arma::mat Mydata( n, k_col );

  //generate model from raw data
  arma::vec S_n = mydata.col(0);  //binary exposure
  Mydata.col(0) = S_n;

  //response Y to be generated from model
  arma::vec Y_tmp;
  Y_tmp.zeros(n);

  //loop over num_med mediators
  for(int ind_j = 0; ind_j < num_med; ind_j++){
    arma::vec M_tmp = S_n * alpha_coef(ind_j) + mydata.col( 1 + ind_j); //j-th mediator variable
    Mydata.col( 1 + ind_j ) = M_tmp;
    Y_tmp =  Y_tmp + M_tmp * beta_coef(ind_j);
  }

  Y_tmp = Y_tmp + mydata.col( 1 + num_med ); //error term is the last column of the original data
  Mydata.col( k_col-1 ) = Y_tmp; //error term is the last column of the original data
  
  //Get projected variables
  int df_proj = num_med - 1;
  for(int ind_j = 0; ind_j < num_med; ind_j++){

    //extract the covariates to be projected on
    arma::mat proj_covariate = Mydata.cols(1, num_med);  //read all mediators
    arma::vec M_covariate = proj_covariate.col( ind_j ); //read one selected mediator
    proj_covariate.shed_col( ind_j );                    //delete readed mediator that does not project

    Mydata.col( num_med + 1 + ind_j ) = compute_projection( proj_covariate, M_covariate, df_proj );
    Mydata.col( num_med * 2 + 1 + ind_j ) = compute_projection( proj_covariate, Y_tmp, df_proj );
    
  }

  return Mydata;
}




////////////////////////////////////////////////////////////////////////
//3. function that generates data with additional covariates and preprocess with projection
////////////////////////////////////////////////////////////////////////
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::export()]]
arma::mat gendata_final_proj_C(int n,  const arma::vec& alpha_coef, const arma::vec& beta_coef, 
                               const arma::mat& mydata, const arma::mat& other_covariates, 
                               arma::vec coef_X_alpha, arma::vec coef_X_beta, double direct_effect, int num_med){
  
  int k_col = 1 + 3 * num_med;  //number of columns: S + m mediators + m mediator_projected + Y m different projections
  
  arma::mat Mydata( n, k_col );
  
  int n_other = other_covariates.n_cols;
  
  //generate model from raw data
  arma::vec S_n = mydata.col(0);  //binary exposure
  arma::vec S_proj = compute_projection( other_covariates, S_n, n_other );
  Mydata.col(0) = S_proj;
  
  //response Y to be generated from model
  arma::vec Y_tmp;
  Y_tmp.zeros(n);
  
  //orginal data without projection
  arma::mat data_original(n, 2 + num_med );
  data_original.col(0) = S_n;
  
  //loop over num_med mediators
  for(int ind_j = 0; ind_j < num_med; ind_j++){
    arma::vec M_tmp = S_n * alpha_coef(ind_j) + other_covariates * coef_X_alpha + mydata.col( 1 + ind_j); //j-th mediator variable
    Y_tmp =  Y_tmp + M_tmp * beta_coef(ind_j);
    
    //projection in M-S model
    arma::vec M_proj_tmp_1 = compute_projection( other_covariates, M_tmp, n_other );
    
    //save projected data
    Mydata.col( 1 + ind_j ) = M_proj_tmp_1; //M_tmp;
    
    //save original data
    data_original.col( 1 + ind_j ) = M_tmp;
  }
  
  //build original Y-M model
  Y_tmp = Y_tmp + S_n * direct_effect + other_covariates * coef_X_beta  + mydata.col( 1 + num_med ); //error term is the last column of the original data
  // Mydata.col( k_col-1 ) = Y_tmp; 
  
  data_original.col( 1 + num_med ) = Y_tmp; 
  
  //projection in Y-M model
  int df_proj = num_med - 1;
  for(int ind_j = 0; ind_j < num_med; ind_j++){
    
    //extract the covariates to be projected on
    arma::mat proj_covariate = join_rows( data_original.cols(1, num_med), S_n, other_covariates);  //read all mediators
    arma::vec M_covariate = proj_covariate.col( ind_j ); //read one selected mediator
    proj_covariate.shed_col( ind_j );                    //delete readed mediator that does not project
    
    Mydata.col( num_med + 1 + ind_j ) = compute_projection( proj_covariate, M_covariate, df_proj );
    Mydata.col( num_med * 2 + 1 + ind_j ) = compute_projection( proj_covariate, Y_tmp, df_proj );
  }
  
  //Mydata column (0): S_proj; (1)-(m) M_proj in M-S model; (m+1)-(2m) M proj in Y-M Model + (2m+1)-(3m) Y proj in Y-M model
  return Mydata;
}






////////////////////////////////////////////////////////////////////////
//4. function that takes original data and only projects
////////////////////////////////////////////////////////////////////////
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::export()]]
arma::mat gendata_orignal_proj_only_C(int n,  const arma::vec& alpha_coef, const arma::vec& beta_coef, 
                                               const arma::mat& mydata, int num_med){
  
  //the input data mydata contains (2+m) columns in total: S + m mediators + Y 
  
  int k_col = 1 + 3 * num_med;  //number of columns: S + m mediators + m mediator_projected + Y m different projections
  
  arma::mat Mydata( n, k_col );
  
  //generate model from raw data
  arma::vec S_n = mydata.col(0);  //binary exposure
  Mydata.col(0) = S_n;

  arma::vec Y_tmp = mydata.col( 1+num_med); 
  
  //Get projected variables
  int df_proj = num_med - 1;
  for(int ind_j = 0; ind_j < num_med; ind_j++){
    
    //extract the covariates to be projected on
    arma::mat proj_covariate = mydata.cols(1, num_med);  //read all mediators
    arma::vec M_covariate = proj_covariate.col( ind_j ); //read one selected mediator
    proj_covariate.shed_col( ind_j );                    //delete readed mediator that does not project
    
    //save the original M variables
    Mydata.col( 1 + ind_j) = M_covariate;
    
    //save the projected M and Y variables in Y-M model
    Mydata.col( num_med + 1 + ind_j ) = compute_projection( proj_covariate, M_covariate, df_proj );
    Mydata.col( num_med * 2 + 1 + ind_j ) = compute_projection( proj_covariate, Y_tmp, df_proj );
    
  }
  
  return Mydata;
}


