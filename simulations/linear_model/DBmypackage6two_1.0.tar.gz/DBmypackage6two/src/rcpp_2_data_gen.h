//
//  rcpp_data_gen.h
//  
//
//  Created by Y H on 9/6/21.
//

#ifndef rcpp_2_data_gen_h
#define rcpp_2_data_gen_h

arma::mat gendata_final_mult_simplified_C(int n,  const arma::vec& alpha_coef, const arma::vec& beta_coef, 
                                          const arma::mat& mydata, int num_med);

arma::mat gendata_final_mult_simplified_proj_C(int n,  const arma::vec& alpha_coef, const arma::vec& beta_coef, 
                                               const arma::mat& mydata, int num_med);

arma::mat gendata_final_proj_C(int n,  const arma::vec& alpha_coef, const arma::vec& beta_coef, 
                               const arma::mat& mydata, const arma::mat& other_covariates, 
                               arma::vec coef_X_alpha, arma::vec coef_X_beta, double direct_effect, int num_med);

arma::mat gendata_orignal_proj_only_C(int n,  const arma::vec& alpha_coef, const arma::vec& beta_coef, 
                                      const arma::mat& mydata, int num_med);

#endif /* rcpp_2_data_gen_h */
