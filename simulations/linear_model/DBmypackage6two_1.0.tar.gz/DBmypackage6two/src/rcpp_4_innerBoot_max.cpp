#include "RcppArmadillo.h"
#include "rcpp_1_prepare.h"
#include "rcpp_2_data_gen.h"
#include "rcpp_3_compute_max_stat.h"

#include <Rcpp.h>
#include <vector>

// [[Rcpp::depends(RcppArmadillo)]]

////////////////////////////////////////////////////////////////////////
//function that does the inner loop of the double bootstrap 
////////////////////////////////////////////////////////////////////////
// [[Rcpp::export()]]
double one_inner_boot_max_C(arma::mat Bootdata_outer, int n, int num_other_alpha, int num_other_beta, 
                        double T_hat_all, double T_hat_star, int N_boot_in, 
                        arma::vec BootZ_alpha, arma::vec BootZ_beta, 
                        arma::mat Boot_res_alpha, arma::mat Boot_res_beta, 
                        double lambda_n1, double lambda_n2, int num_med){
  
  double Boot_inner_p_val = 0;
  double tmp_ind_inner = 0;
  
  //loop of the inner bootstrap
  for(int in_ind = 0; in_ind < N_boot_in; in_ind++ ){ 
    arma::uvec unifnum = ind_sample(n); 
    
    arma::mat Bootdata_inner = Bootdata_outer.rows(unifnum);
    Rcpp::List tmp_starstar = computeTest_max_C(Bootdata_inner, n, num_other_alpha, num_other_beta, num_med);
    
    double T_hat_starstar = tmp_starstar["T_hat_all"];
    
    arma::vec InBootZ_alpha = tmp_starstar["Z_alpha"];
    arma::vec InBootZ_beta = tmp_starstar["Z_beta"];
    arma::vec InBootCoef_alpha = tmp_starstar["Coef_alpha"];
    arma::vec InBootCoef_beta = tmp_starstar["Coef_beta"];
    arma::mat InBoot_res_alpha = tmp_starstar["res_alpha"];
    arma::mat InBoot_res_beta = tmp_starstar["res_beta"];
    arma::vec InBootSigma_alpha = tmp_starstar["sigma_alpha"];
    arma::vec InBootSigma_beta = tmp_starstar["sigma_beta"];
    
    double BootSobelTestTmp = ThresOnebootComp_max_C(n, num_other_alpha, num_other_beta, Bootdata_inner, 
                                                 T_hat_star, T_hat_starstar, unifnum, num_med, 
                                                 BootZ_alpha, BootZ_beta, Boot_res_alpha, Boot_res_beta, 
                                                 InBootZ_alpha, InBootZ_beta,
                                                 InBootCoef_alpha, InBootCoef_beta, 
                                                 InBoot_res_alpha, InBoot_res_beta,
                                                 InBootSigma_alpha, InBootSigma_beta,
                                                 lambda_n1, lambda_n2);
    
    tmp_ind_inner = (BootSobelTestTmp > (T_hat_star - T_hat_all));
    
    Boot_inner_p_val = Boot_inner_p_val + tmp_ind_inner; //conv_to<double>::from(tmp_ind_inner);
  }
  
  Boot_inner_p_val =  Boot_inner_p_val / N_boot_in;
  
  return Boot_inner_p_val;
}





