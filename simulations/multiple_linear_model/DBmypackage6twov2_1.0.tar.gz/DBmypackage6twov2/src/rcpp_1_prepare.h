//
//  rcpp_prepare.h
//  
//
//  Created by Y H on 9/4/21.
//

#ifndef rcpp_1_prepare_h
#define rcpp_1_prepare_h

Rcpp::List fastLmV(const arma::mat& X, const arma::colvec& y, const int k);

arma::uvec ind_sample( int n); 

arma::vec compute_projection(arma::mat proj_covariate, arma::vec response_var, const int k);


#endif /* rcpp_1_prepare_h */
