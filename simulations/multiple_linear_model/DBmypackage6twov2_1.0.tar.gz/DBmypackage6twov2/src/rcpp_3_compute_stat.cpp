//This file contains functions for computing basic product statistics and also the bootstrap version with thresholds

#include "RcppArmadillo.h"
#include "rcpp_1_prepare.h"
#include "rcpp_2_data_gen.h"

#include <Rcpp.h>
#include <vector>



// [[Rcpp::depends(RcppArmadillo)]]



/////////////////////////////////////////////////////////////////////////////////////////////
//1. Compute the product test statistic without indicators (also for computing theta hat star)
/////////////////////////////////////////////////////////////////////////////////////////////
// [[Rcpp::export()]]
Rcpp::List computeTest_C(arma::mat mydata, int n, int num_other_alpha,  int num_other_beta, int num_med){
  // arma::vec Y_proj_1 = mydata.col(0); //projected Y variable for beta 1
  // arma::vec Y_proj_2 = mydata.col(1); //projected Y variable for beta 2
  // arma::vec S_n = mydata.col(2); 
  // arma::vec M_n1 = mydata.col(3);     //orginal M1 variable
  // arma::vec M_n2 = mydata.col(4);     //orginal M2 variable
  // arma::vec M_proj_1 = mydata.col(5); //projected M1 variable for beta 1
  // arma::vec M_proj_2 = mydata.col(6); //projected M2 variable for beta 2
  
  int k_alpha = num_other_alpha + 1;   //plus 1 because of the degrees of freedom of the regression covariate itself
  int k_beta = num_other_beta + num_med + 1; //additional num_med-1 from the projection adjustment, as we have 2 covariates now
  
  arma::vec Z_alpha(num_med);
  arma::vec Z_beta(num_med);
  arma::vec Coef_alpha(num_med);
  arma::vec Coef_beta(num_med);
  arma::mat res_alpha(n, num_med);
  arma::mat res_beta(n, num_med);
  
  for(int ind_j = 0; ind_j < num_med; ind_j++){
    arma::vec S_tmp = mydata.col( 0 ); 
    arma::vec M_tmp = mydata.col( 1 + ind_j );
    Rcpp::List lm_alpha_tmp = fastLmV( S_tmp,  M_tmp, k_alpha);
    Coef_alpha(ind_j) = lm_alpha_tmp["coefficients"];
    Z_alpha(ind_j) = lm_alpha_tmp["t.value"];
    arma::vec res_alpha_tmp = lm_alpha_tmp["residuals"];
    res_alpha.col(ind_j) = res_alpha_tmp;
    
    arma::vec M_proj_tmp = mydata.col( num_med + 1 + ind_j );
    arma::vec Y_proj_tmp = mydata.col( 2 * num_med + 1 + ind_j );
    Rcpp::List lm_beta_tmp = fastLmV( M_proj_tmp, Y_proj_tmp, k_beta );
    Coef_beta(ind_j) = lm_beta_tmp["coefficients"];
    Z_beta(ind_j) = lm_beta_tmp["t.value"];
    arma::vec res_beta_tmp = lm_beta_tmp["residuals"];
    res_beta.col(ind_j) = res_beta_tmp;
    
  }
  
  double Test_nosd_prod = sqrt(n) * std::inner_product( Coef_alpha.begin(), Coef_alpha.end() , Coef_beta.begin(), 0.0);
  
  return Rcpp::List::create(Rcpp::Named("T_hat_all") = Test_nosd_prod,
                            Rcpp::Named("Coef_alpha") = Coef_alpha,
                            Rcpp::Named("Coef_beta") = Coef_beta,
                            Rcpp::Named("Z_alpha") = Z_alpha,
                            Rcpp::Named("Z_beta") = Z_beta,
                            Rcpp::Named("res_alpha") = res_alpha,
                            Rcpp::Named("res_beta") = res_beta);
}


///////////////////////////////////////////////////////////////////////////////////////////////
//2. compute An value function for each coefficient
///////////////////////////////////////////////////////////////////////////////////////////////
// [[Rcpp::export()]]
double computeAnStar_C(int n, arma::vec X_boot, arma::vec lm_res, arma::uvec unifnum){
  
  arma::vec bootres = lm_res.elem(unifnum); 
  double A_Coef = std::inner_product( bootres.begin(), bootres.end() , X_boot.begin(), 0.0)/ ( as_scalar( arma::sum(pow( X_boot, 2 ) ) ));
  
  //it is necessary to have a bootstrap for residuals too
  // double A_Coef = std::inner_product( lm_res.begin(), lm_res.end() , X_boot.begin(), 0.0)/ ( as_scalar( arma::sum(pow( X_boot, 2 ) ) ));
  
  return A_Coef;
}


///////////////////////////////////////////////////////////////////////////////////////////////
//3. Computes bootstrap test statistic (with indicators) in one iteration of bootstrap
///////////////////////////////////////////////////////////////////////////////////////////////
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::export()]]
double ThresOnebootComp_C(int n, int num_other_alpha, int num_other_beta, arma::mat Bootdata_outer,
                          double T_hat_all, double T_hat_star, arma::uvec unifnum, int num_med, 
                          arma::vec Z_alpha, arma::vec Z_beta, arma::mat res_alpha, arma::mat res_beta, 
                          arma::vec BootZ_alpha, arma::vec BootZ_beta, 
                          arma::vec BootCoef_alpha, arma::vec BootCoef_beta,
                          arma::mat Boot_res_alpha, arma::mat Boot_res_beta, 
                          double lambda_n1, double lambda_n2){ 
  
  //I. compute all An values of coefficients (covaraite * residual)
  //I. 1. definition
  arma::vec BootA_alpha(num_med);    //save bootstrapped alpha A values
  arma::vec BootA_beta(num_med); 
  
  //I. 2. compute An
  for(int ind_j = 0; ind_j < num_med; ind_j++){
    arma::vec BootS_tmp = Bootdata_outer.col(0);         //read the bootstrapped exposure variable
    BootA_alpha(ind_j) = computeAnStar_C(n, BootS_tmp, res_alpha.col(ind_j), unifnum); 
    
    arma::vec BootM_proj_tmp = Bootdata_outer.col( num_med + 1 + ind_j);   //read the projected exposure variable
    BootA_beta(ind_j) = computeAnStar_C(n, BootM_proj_tmp, res_beta.col(ind_j), unifnum); 
  }
  
  // double tmp1 = sqrt(n) * std::inner_product( BootCoef_alpha.begin(), BootCoef_alpha.end() , BootCoef_beta.begin(), 0.0);
  // double tmp2 = sqrt(n) * std::inner_product( BootA_alpha.begin(), BootA_alpha.end() , BootA_beta.begin(), 0.0);
  
  // Rcpp::Rcout << "alpha*beta: " << tmp1 << std::endl;
  // Rcpp::Rcout << "T_hat_star - T_hat_all: " << T_hat_star - T_hat_all << std::endl;
  // Rcpp::Rcout << "Aalpha*Abeta: " << tmp2 << std::endl;
  // Rcpp::Rcout << "Zalpha: " << Z_alpha << std::endl;
  // Rcpp::Rcout << "Zbeta: " << Z_beta << std::endl;
  // Rcpp::Rcout << "BootZ_alpha: " << BootZ_alpha << std::endl;
  // Rcpp::Rcout << "BootZ_beta: " << BootZ_beta << std::endl;
  // Rcpp::Rcout << "Aalpha: " << BootA_alpha << std::endl;
  // Rcpp::Rcout << "Abeta: " << BootA_beta << std::endl;

  
  //II. Indicator part
  bool indic1 = FALSE; 
  int count_num = 0;
  for(int ind_j = 0; ind_j < num_med; ind_j++){
    if(std::abs(Z_alpha(ind_j)) <= lambda_n1 & std::abs(BootZ_alpha(ind_j)) <= lambda_n1)
    {
      count_num += 1;
    }
    if(std::abs(Z_beta(ind_j)) <= lambda_n2 & std::abs(BootZ_beta(ind_j)) <= lambda_n2)
    {
      count_num += 1;
    }
  }
  // Rcpp::Rcout << "count_num: " << count_num << std::endl;
  
  if (count_num == (num_med * 2)){
    indic1 = TRUE;
    BootCoef_alpha = BootA_alpha;
    BootCoef_beta = BootA_beta;
  }
  double BootNonStdProd = 0;
  if (! indic1 ){
    BootNonStdProd = T_hat_star; //bootstrap product statistic - orignal data product statistic
  } else {
    BootNonStdProd = sqrt(n) * std::inner_product( BootCoef_alpha.begin(), BootCoef_alpha.end() , BootCoef_beta.begin(), 0.0) - T_hat_all;
  }
  
  return BootNonStdProd;
}



