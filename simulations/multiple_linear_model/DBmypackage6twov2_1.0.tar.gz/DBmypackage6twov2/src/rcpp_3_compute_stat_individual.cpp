//This file contains functions for computing basic product statistics and also the bootstrap version with thresholds

#include "RcppArmadillo.h"
#include "rcpp_1_prepare.h"
#include "rcpp_2_data_gen.h"
#include "rcpp_3_compute_stat.h"

#include <Rcpp.h>
#include <vector>



// [[Rcpp::depends(RcppArmadillo)]]

///////////////////////////////////////////////////////////////////////////////////////////////
//3. Computes bootstrap test statistic (with indicators) in one iteration of bootstrap
///////////////////////////////////////////////////////////////////////////////////////////////
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::export()]]
double ThresOnebootComp_C_individual(int n, int num_other_alpha, int num_other_beta, arma::mat Bootdata_outer,
                          double T_hat_all, double T_hat_star, arma::uvec unifnum, int num_med, 
                          arma::vec Z_alpha, arma::vec Z_beta, arma::mat res_alpha, arma::mat res_beta, 
                          arma::vec BootZ_alpha, arma::vec BootZ_beta, 
                          arma::vec BootCoef_alpha, arma::vec BootCoef_beta,
                          arma::mat Boot_res_alpha, arma::mat Boot_res_beta, 
                          double lambda_n1, double lambda_n2){ 
  
  //I. compute all An values of coefficients (covaraite * residual)
  //I. 1. definition
  arma::vec BootA_alpha(num_med);    //save bootstrapped alpha A values
  arma::vec BootA_beta(num_med); 
  
  //I. 2. compute An
  for(int ind_j = 0; ind_j < num_med; ind_j++){
    arma::vec BootS_tmp = Bootdata_outer.col(0);         //read the bootstrapped exposure variable
    BootA_alpha(ind_j) = computeAnStar_C(n, BootS_tmp, res_alpha.col(ind_j), unifnum); 
    
    arma::vec BootM_proj_tmp = Bootdata_outer.col( num_med + 1 + ind_j);   //read the projected exposure variable
    BootA_beta(ind_j) = computeAnStar_C(n, BootM_proj_tmp, res_beta.col(ind_j), unifnum); 
  }
  
  //II. Indicator part
  bool indic1 = FALSE; 
  int count_num = 0;
  for(int ind_j = 0; ind_j < num_med; ind_j++){
    if(std::abs(Z_alpha(ind_j)) <= lambda_n1 & std::abs(BootZ_alpha(ind_j)) <= lambda_n1)
    {
      BootCoef_alpha(ind_j) = BootA_alpha(ind_j);
      count_num += 1;
    }
    if(std::abs(Z_beta(ind_j)) <= lambda_n2 & std::abs(BootZ_beta(ind_j)) <= lambda_n2)
    {
      BootCoef_beta(ind_j) = BootA_beta(ind_j);
      count_num += 1;
    }
  }
  if (count_num == (num_med * 2)){
    indic1 = TRUE;
    BootCoef_alpha = BootA_alpha;
    BootCoef_beta = BootA_beta;
  }
  double BootNonStdProd = 0;
  if (! indic1 ){
    BootNonStdProd = T_hat_star - T_hat_all; //bootstrap product statistic - orignal data product statistic
  } else {
    BootNonStdProd = sqrt(n) * std::inner_product( BootCoef_alpha.begin(), BootCoef_alpha.end() , BootCoef_beta.begin(), 0.0);
  }
  
  return BootNonStdProd;
}



