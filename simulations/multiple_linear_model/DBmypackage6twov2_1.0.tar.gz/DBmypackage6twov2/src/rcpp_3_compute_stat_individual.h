//
//  rcpp_3_compute_stat_individual.h
//  
//
//  Created by Y H on 9/6/21.
//

#ifndef rcpp_3_compute_stat_individual_h
#define rcpp_3_compute_stat_individual_h

double ThresOnebootComp_C_individual(int n, int num_other_alpha, int num_other_beta, arma::mat Bootdata_outer,
                          double T_hat_all, double T_hat_star, arma::uvec unifnum, int num_med, 
                          arma::vec Z_alpha, arma::vec Z_beta, arma::mat res_alpha, arma::mat res_beta, 
                          arma::vec BootZ_alpha, arma::vec BootZ_beta, 
                          arma::vec BootCoef_alpha, arma::vec BootCoef_beta,
                          arma::mat Boot_res_alpha, arma::mat Boot_res_beta, 
                          double lambda_n1, double lambda_n2); 

#endif /* rcpp_3_compute_stat_individual_h */
