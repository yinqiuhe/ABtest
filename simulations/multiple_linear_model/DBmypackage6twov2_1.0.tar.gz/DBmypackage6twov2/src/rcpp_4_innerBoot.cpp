#include "RcppArmadillo.h"
#include "rcpp_1_prepare.h"
#include "rcpp_2_data_gen.h"
#include "rcpp_2_data_gen_X.h"
#include "rcpp_3_compute_stat.h"

#include <Rcpp.h>
#include <vector>

// [[Rcpp::depends(RcppArmadillo)]]

////////////////////////////////////////////////////////////////////////
//function that does the inner loop of the double bootstrap 
////////////////////////////////////////////////////////////////////////
// [[Rcpp::export()]]
double one_inner_boot_C(arma::mat Bootdata_outer, arma::mat Boot_other_covariates,
                        int n, int num_other_alpha, int num_other_beta, 
                        double T_hat_all, double T_hat_star, int N_boot_in, 
                        arma::vec BootZ_alpha, arma::vec BootZ_beta, 
                        arma::mat Boot_res_alpha, arma::mat Boot_res_beta, 
                        double lambda_n1, double lambda_n2, int num_med){
  
  double Boot_inner_p_val = 0;
  double tmp_ind_inner = 0;
  
  //save inner boot individual coefficients
  // arma::mat inner_Boot_alpha(N_boot_out, num_med);
  // arma::mat inner_Boot_beta(N_boot_out, num_med);
  
  //loop of the inner bootstrap
  for(int in_ind = 0; in_ind < N_boot_in; in_ind++ ){ 
    arma::uvec unifnum = ind_sample(n); 
    
    // arma::mat Bootdata_inner = Bootdata_outer.rows(unifnum);
    arma::mat Bootdata_inner_tmp = Bootdata_outer.rows(unifnum);
    arma::mat Boot_inner_other_covariates = Boot_other_covariates.rows(unifnum); 
    arma::mat Bootdata_inner = gendata_proj_X_C(n,  Bootdata_inner_tmp, Boot_inner_other_covariates, num_med);
    
    Rcpp::List tmp_starstar = computeTest_C(Bootdata_inner, n, num_other_alpha, num_other_beta, num_med);
    
    double T_hat_starstar = tmp_starstar["T_hat_all"];
    
    arma::vec InBootZ_alpha = tmp_starstar["Z_alpha"];
    arma::vec InBootZ_beta = tmp_starstar["Z_beta"];
    arma::vec InBootCoef_alpha = tmp_starstar["Coef_alpha"];
    arma::vec InBootCoef_beta = tmp_starstar["Coef_beta"];
    arma::mat InBoot_res_alpha = tmp_starstar["res_alpha"];
    arma::mat InBoot_res_beta = tmp_starstar["res_beta"];
    
    // Rcpp::Rcout << "In_boot_Zalpha: " << BootZ_alpha << std::endl;
    // Rcpp::Rcout << "In_boot_Zbeta: " << BootZ_beta << std::endl;
    // Rcpp::Rcout << "InBootZ_alpha: " << InBootZ_alpha << std::endl;
    // Rcpp::Rcout << "InBootZ_beta: " << InBootZ_beta << std::endl;
    // Rcpp::Rcout << "InBootCoef_alpha: " << InBootCoef_alpha << std::endl;
    // Rcpp::Rcout << "InBootCoef_beta: " << InBootCoef_beta << std::endl;
    
    double BootSobelTestTmp = ThresOnebootComp_C(n, num_other_alpha, num_other_beta, Bootdata_inner, 
                                                 T_hat_star, T_hat_starstar, unifnum, num_med, 
                                                 BootZ_alpha, BootZ_beta, Boot_res_alpha, Boot_res_beta, 
                                                 InBootZ_alpha, InBootZ_beta,
                                                 InBootCoef_alpha, InBootCoef_beta, InBoot_res_alpha, InBoot_res_beta, 
                                                 lambda_n1, lambda_n2);
    
    // Rcpp::Rcout << "Inner_BootSobelTestTmp: " << BootSobelTestTmp << std::endl;
    // Rcpp::Rcout << "Inner_T_hat_star - T_hat_all: " << T_hat_star - T_hat_all << std::endl;
    
    tmp_ind_inner = (BootSobelTestTmp > (T_hat_star - T_hat_all));

    Boot_inner_p_val = Boot_inner_p_val + tmp_ind_inner; //conv_to<double>::from(tmp_ind_inner);
  }
  
  Boot_inner_p_val =  Boot_inner_p_val / N_boot_in;
  
  double Boot_inner_p_val2 = 2 * min( Rcpp::NumericVector::create( Boot_inner_p_val, (1-Boot_inner_p_val) ) );
  
  return Boot_inner_p_val2;
  // return Boot_inner_p_val;
}





