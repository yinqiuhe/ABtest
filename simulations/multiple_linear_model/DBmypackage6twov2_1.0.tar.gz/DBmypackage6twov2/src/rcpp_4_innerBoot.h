//
//  rcpp_4_innerBoot.h
//  
//
//  Created by Y H on 9/7/21.
//

#ifndef rcpp_4_innerBoot_h
#define rcpp_4_innerBoot_h

double one_inner_boot_C(arma::mat Bootdata_outer, arma::mat Boot_other_covariates, 
                        int n, int num_other_alpha, int num_other_beta, 
                        double T_hat_all, double T_hat_star, int N_boot_in, 
                        arma::vec BootZ_alpha, arma::vec BootZ_beta, 
                        arma::mat Boot_res_alpha, arma::mat Boot_res_beta, 
                        double lambda_n1, double lambda_n2, int num_med);
  
double one_in_boot_coef(arma::mat Bootdata_outer, arma::mat Boot_other_covariates,
                        int n, int num_other_alpha, int num_other_beta, 
                        double T_hat_all, double T_hat_star, int N_boot_in, 
                        arma::vec BootZ_alpha, arma::vec BootZ_beta, 
                        arma::mat Boot_res_alpha, arma::mat Boot_res_beta, 
                        double lambda_n1, double lambda_n2, int num_med,
                        arma::vec Coef_alpha, arma::vec BootCoef_alpha);
    
#endif /* rcpp_4_innerBoot_h */
