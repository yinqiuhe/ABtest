#include "RcppArmadillo.h"
#include "rcpp_1_prepare.h"
#include "rcpp_2_data_gen.h"
#include "rcpp_2_data_gen_X.h"
#include "rcpp_3_compute_stat.h"
#include "rcpp_3_compute_stat_individual.h"
#include "rcpp_4_innerBoot.h"

#include <Rcpp.h>
#include <vector>

// [[Rcpp::depends(RcppArmadillo)]]


////////////////////////////////////////////////////////////////////////
//function that tests if we do not project at first
//input data now should be original data instead of projected data
////////////////////////////////////////////////////////////////////////
// [[Rcpp::export()]]
Rcpp::List doubleBoot_X_noproj_individual(arma::mat mydata, arma::mat other_covariates,
                                double T_hat_all, int n,  int num_other_alpha, int num_other_beta, 
                                int N_boot_out, int N_boot_in, 
                                arma::vec Z_alpha, arma::vec Z_beta, arma::mat res_alpha, arma::mat res_beta,
                                arma::vec Coef_alpha, arma::vec Coef_beta,
                                arma::vec alpha_coef, arma::vec beta_coef,
                                double lambda_n1, double lambda_n2, double omega, int num_med){
  
  //II. preparation for outer bootstrap record
  double out_Boot_inner_dec = 0;
  arma::vec out_Boot_test(N_boot_out);
  arma::vec all_class_Boot(N_boot_out);
  arma::mat Boot_alpha(N_boot_out, num_med);
  arma::mat Boot_beta(N_boot_out, num_med);
  
  //III. Loop of the outer bootstrap
  for(int out_ind = 0; out_ind < N_boot_out; out_ind++){
    
    //III.1: get bootstrap sample for the outer loop
    arma::uvec unif_ind_out =  ind_sample(n);
    arma::mat Bootdata_outer_tmp = mydata.rows(unif_ind_out);
    arma::mat Boot_other_covariates = other_covariates.rows(unif_ind_out); 
    arma::mat Bootdata_outer = gendata_proj_X_C(n,  Bootdata_outer_tmp, Boot_other_covariates, num_med);

    //III.2: compute outer bootstrap information: theta.hat.star, and coefficients.star, and Z statistics.star
    Rcpp::List tmp_star = computeTest_C(Bootdata_outer, n, num_other_alpha, num_other_beta, num_med);
    double T_hat_star = tmp_star["T_hat_all"]; // get the bootstrap product test statistic
    all_class_Boot(out_ind) = T_hat_star;      //save the classical bootstrapped product test statistic
    
    //III. 2.1: reading regression results, coefficients and Z statistics
    arma::vec BootZ_alpha = tmp_star["Z_alpha"];
    arma::vec BootZ_beta = tmp_star["Z_beta"];
    
    arma::vec BootCoef_alpha = tmp_star["Coef_alpha"];
    arma::vec BootCoef_beta = tmp_star["Coef_beta"];
    
    arma::mat Boot_res_alpha = tmp_star["res_alpha"];
    arma::mat Boot_res_beta = tmp_star["res_beta"];
    
    Boot_alpha.row( out_ind ) = BootCoef_alpha.t();
    Boot_beta.row( out_ind ) = BootCoef_beta.t();
    
    //III. 3: compute one bootstrap statistic with thresholding: lm from original data is passed to get the residuals
    double Boot_res_one = ThresOnebootComp_C_individual(n, num_other_alpha, num_other_beta, Bootdata_outer, 
                                             T_hat_all, T_hat_star, unif_ind_out, num_med,
                                             Z_alpha, Z_beta, res_alpha, res_beta, BootZ_alpha, BootZ_beta, 
                                             BootCoef_alpha, BootCoef_beta, Boot_res_alpha, Boot_res_beta,
                                             lambda_n1, lambda_n2);
    
    out_Boot_test(out_ind) = Boot_res_one;
    
    
    // IV: double bootstrap to compute rejection proportion for theta.hat.star - theta.hat
    double inner_boot_res = 0; 
    // one_inner_boot_C(Bootdata_outer, n, num_other_alpha, num_other_beta,
    //                                          T_hat_all, T_hat_star, N_boot_in,
    //                                          BootZ_alpha, BootZ_beta, Boot_res_alpha, Boot_res_beta,
    //                                          lambda_n1, lambda_n2, num_med);
    
    double rej_dec = ( inner_boot_res < omega );  //omega is the testing threshold
    out_Boot_inner_dec = out_Boot_inner_dec + rej_dec;
  }
  
  out_Boot_inner_dec = out_Boot_inner_dec/N_boot_out; //proportion of rejection from the inner bootstrap for given pair of lambdas, which will be used to choose lambda
  
  double tmp_p_val1 = mean( arma::conv_to<arma::vec>::from(out_Boot_test > T_hat_all ) );
  double p_val_outer = 2 * min( Rcpp::NumericVector::create( tmp_p_val1, (1-tmp_p_val1) ) );
  
  double tmp_p_val_class2 = mean(arma::conv_to<arma::vec>::from( all_class_Boot > 0) );
  double p_val_class = 2 * min( Rcpp::NumericVector::create( tmp_p_val_class2, (1- tmp_p_val_class2) ) );
  
  //compute bootstrap p-values for individual coefficients
  arma::vec p_val_alpha(num_med);
  arma::vec p_val_beta(num_med);
  
  for(int ind_j = 0; ind_j < num_med; ind_j++){
    arma::vec tmp_center_boot_stat = Boot_alpha.col(ind_j) - Coef_alpha(ind_j); 
    double tmp_center_stat = Coef_alpha(ind_j) - alpha_coef(ind_j);
    double tmp_p_1 = mean( arma::conv_to<arma::vec>::from( tmp_center_boot_stat > tmp_center_stat  )  );
    p_val_alpha(ind_j) = 2 * min( Rcpp::NumericVector::create( tmp_p_1, (1-tmp_p_1) ) );
    
    tmp_center_boot_stat = Boot_beta.col(ind_j) - Coef_beta(ind_j); 
    tmp_center_stat = Coef_beta(ind_j) - beta_coef(ind_j);
    tmp_p_1 = mean( arma::conv_to<arma::vec>::from( tmp_center_boot_stat > tmp_center_stat )  );
    p_val_beta(ind_j) = 2 * min( Rcpp::NumericVector::create( tmp_p_1, (1-tmp_p_1) ) );
  }
  
  return Rcpp::List::create(Rcpp::Named("testRes") = out_Boot_test,
                            Rcpp::Named("p_val_outer") = p_val_outer,
                            Rcpp::Named("rej_prop") = out_Boot_inner_dec,
                            Rcpp::Named("p_val_class") = p_val_class,
                            Rcpp::Named("p_val_alpha") = p_val_alpha, 
                            Rcpp::Named("p_val_beta") = p_val_beta);
}



