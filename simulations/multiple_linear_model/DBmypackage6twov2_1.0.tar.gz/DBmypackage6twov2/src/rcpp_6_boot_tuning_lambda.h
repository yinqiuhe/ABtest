//
//  rcpp_6_boot_tuning_lambda.h
//  
//
//  Created by Y H on 22/12/21.
//

#ifndef rcpp_6_boot_tuning_lambda_h
#define rcpp_6_boot_tuning_lambda_h

arma::mat compute_multi_proj(arma::mat proj_covariate, arma::mat response_var, const int k);

Rcpp::List boot_tuning_par_C(const arma::mat& mydata_original, arma::mat& other_covariates, 
                             int n, double omega, int num_med,
                             double lambda_n1, double lambda_n2, 
                             int N_boot_out, int N_boot_in,
                             int num_other_alpha, int num_other_beta);

Rcpp::List boot_tuning_par_two_C(const arma::mat& mydata_original, arma::mat& other_covariates, 
                                 int n, double omega, int num_med,
                                 double lambda_n1_alpha, double lambda_n2_alpha, 
                                 double lambda_n1_beta, double lambda_n2_beta, 
                                 double lambda_n1_both, double lambda_n2_both, 
                                 int N_boot_out, int N_boot_in,
                                 int num_other_alpha, int num_other_beta);

Rcpp::List boot_tuning_par_three_C(const arma::mat& mydata_original, arma::mat& other_covariates, 
                                   int n, double omega, int num_med,
                                   double lambda_n1_alpha, double lambda_n2_alpha, 
                                   double lambda_n1_beta, double lambda_n2_beta, 
                                   double lambda_n1_both, double lambda_n2_both, 
                                   int N_boot_out, int N_boot_in,
                                   int num_other_alpha, int num_other_beta);

#endif /* rcpp_6_boot_tuning_lambda_h */
