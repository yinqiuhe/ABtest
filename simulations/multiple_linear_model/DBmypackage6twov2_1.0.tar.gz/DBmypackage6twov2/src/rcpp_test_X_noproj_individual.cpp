#include "RcppArmadillo.h"
#include "rcpp_1_prepare.h"
#include "rcpp_2_data_gen.h"
#include "rcpp_2_data_gen_X.h"
#include "rcpp_3_compute_stat.h"
#include "rcpp_4_innerBoot.h"
#include "rcpp_5_doubleBoot_X_noproj_individual.h"

#include <Rcpp.h>
#include <vector>

// [[Rcpp::depends(RcppArmadillo)]]

////////////////////////////////////////////////////////////////////////
//function that runs each Monte Carlo
////////////////////////////////////////////////////////////////////////
// [[Rcpp::export()]]
arma::vec One_MC_DB_X_noProj_C_individual(int mc_ind, const arma::mat& mydata_original, arma::mat& other_covariates, 
                               int n, int num_other_alpha, int num_other_beta,  
                               double omega, const arma::vec& alpha_coef, const arma::vec& beta_coef, int num_med,
                               Rcpp::NumericVector lambda1all, Rcpp::NumericVector lambda2all, int N_boot_out, int N_boot_in){
  
  //I. Prepartion: define variables
  arma::vec out_Boot_test( N_boot_out );
  double out_Boot_p_val; 
  double out_Boot_rej_prop;
  
  double lambda_1_chosen = 1;
  double lambda_2_chosen = 1;
  
  //Save individual coefficients p-values
  arma::vec p_val_alpha(num_med);
  arma::vec p_val_beta(num_med);
  
  
  //II. compute product test statistic from the input data (with projection already)
  //the input is the original data from the model, we need process to get the projection
  arma::mat mydata = gendata_proj_X_C(n, mydata_original, other_covariates, num_med); //compute the projected data
  
  Rcpp::List tmp = computeTest_C(mydata, n, num_other_alpha, num_other_beta, num_med);
  double T_hat_all = tmp["T_hat_all"]; //get the product statistic from readed data
  
  
  //II.2: get regression Z values, i.e., t-statistics
  arma::vec Z_alpha = tmp["Z_alpha"]; 
  arma::vec Z_beta = tmp["Z_beta"]; 
  
  arma::vec Coef_alpha = tmp["Coef_alpha"];
  arma::vec Coef_beta = tmp["Coef_beta"];
  
  arma::mat res_alpha = tmp["res_alpha"]; 
  arma::mat res_beta = tmp["res_beta"]; 
   
  //III.1: Prepartion for searching over lambda values 
  double out_Boot_rej_prop_flag = arma::datum::inf; // = {R_PosInf, R_PosInf};
  double out_Boot_rej_prop_chosen = arma::datum::inf;
  double out_Boot_rej_prop_flag_tmp = 0;
  double p_val_class = 0;

  Rcpp::List tmp_boot_res;
  
  //III.2: loop for searching over lambda values 
  for( double& lambda1 : lambda1all){
    for( double& lambda2 : lambda2all){
      double lambda_n1 = lambda1 * sqrt(n) / log(n);
      double lambda_n2 = lambda2 * sqrt(n) / log(n);

      tmp_boot_res = doubleBoot_X_noproj_individual(mydata_original, other_covariates,
                                          T_hat_all, n,  num_other_alpha, num_other_beta, N_boot_out, N_boot_in, 
                                          Z_alpha, Z_beta, res_alpha, res_beta, 
                                          Coef_alpha, Coef_beta, alpha_coef, beta_coef, 
                                          lambda_n1, lambda_n2, omega, num_med);
      
      out_Boot_rej_prop = tmp_boot_res["rej_prop"];

      out_Boot_rej_prop_flag_tmp = std::abs(out_Boot_rej_prop - omega); //get rejection proportion closest to omega (nominal level)
      
      if(  out_Boot_rej_prop_flag >  out_Boot_rej_prop_flag_tmp ){
        out_Boot_rej_prop_flag = out_Boot_rej_prop_flag_tmp;
        out_Boot_rej_prop_chosen = out_Boot_rej_prop;            //outer loop: rejection times for those statistics
        arma::vec tmp_out_boot_res = tmp_boot_res["testRes"];    //outer loop: an intermediate variable
        out_Boot_test = tmp_out_boot_res;                        //outer loop: bootstrap statistics
        out_Boot_p_val = tmp_boot_res["p_val_outer"];            //outer loop: p-value of bootstrap stat based on inner loop
        lambda_1_chosen = lambda1;
        lambda_2_chosen = lambda1;
        p_val_class = tmp_boot_res["p_val_class"]; // this returns the classical nonparametric bootstrap
        
        //get individual coefficients p-values
        arma::vec p_val_alpha_tmp = tmp_boot_res["p_val_alpha"];
        p_val_alpha = p_val_alpha_tmp;
        arma::vec p_val_beta_tmp = tmp_boot_res["p_val_beta"];
        p_val_beta = p_val_beta_tmp;
      }
    }
  }
  
  
  //IV: save the outcome values
  int num_col = N_boot_out + 1 + 1 + 1 + 1 + 1 + 1 + 2 * num_med;
  arma::vec one_mc_res(num_col);
  one_mc_res.zeros();
  
  one_mc_res(0) = out_Boot_p_val;
  one_mc_res(1) = out_Boot_rej_prop_chosen;
  one_mc_res(2) = lambda_1_chosen;
  one_mc_res(3) = lambda_2_chosen;
  one_mc_res(4) = T_hat_all; 
  one_mc_res(5) = p_val_class;
  one_mc_res.subvec(6, N_boot_out+5) = out_Boot_test;
  
  one_mc_res.subvec( (N_boot_out + 6), (N_boot_out + 6 + num_med - 1 ) ) = p_val_alpha; 
  one_mc_res.subvec( (N_boot_out + 6 + num_med), (N_boot_out + 6 + 2*num_med - 1 ) ) = p_val_beta; 
    
  return one_mc_res; 
}



